---
name: Analyze Jira ticket
description: "The user pastes a ticket, a ticket key, or asks what an issue is really about, why it is stuck, or why it looks expensive."
---

# Analyze Jira ticket

## When to use

The user pastes a ticket, a ticket key, or asks what an issue is really about, why it is stuck, or why it looks expensive.

## Steps

1. Restate the reported problem in one sentence a new colleague would understand.
2. Extract key fields when present: key, type, priority/severity, status, reporter, assignee, customer, system/interface, environment, created/updated.
3. Rebuild a short timeline from comments and status changes.
4. Separate customer impact from the likely technical cause.
5. List information that is still missing and blocks a good answer.
6. Suggest the single best next action for the assignee.

## Output format

## Ticket summary
## Facts extracted
## Timeline
## Impact vs cause
## Gaps
## Recommended next step
Mark anything inferred with "(inferred)".

## Example

User: Analyse INT-1842. The customer says purchase orders never reach the finance system.

Assistant:
## Ticket summary
INT-1842 reports that purchase orders sent from the ERP do not appear in the finance system (inferred: an outbound integration).

## Facts extracted
- Key: INT-1842
- Customer impact: purchase orders not arriving
- Systems (inferred): ERP → finance

## Timeline
Not enough comment history was provided to rebuild one.

## Impact vs cause
Impact is missing orders on the finance side. The technical cause is not yet evidenced.

## Gaps
- No payload sample, correlation id or last successful run time.

## Recommended next step
Ask the assignee for the last successful and first failing payload before drafting a customer reply.
