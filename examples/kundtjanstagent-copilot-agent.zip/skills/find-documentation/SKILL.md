---
name: Find documentation
description: "The user needs the relevant runbook, mapping, API contract, FAQ or a similar previous case."
---

# Find documentation

## When to use

The user needs the relevant runbook, mapping, API contract, FAQ or a similar previous case.

## Steps

1. Build search terms from the ticket: system names, error text, interface id, customer, message type.
2. Search configured SharePoint/OneDrive and connectors first; use web search only if it is enabled and internal docs are not enough.
3. Return the best matching documents with title, location and why each match is relevant.
4. Quote only the passages that answer the question.
5. If nothing relevant is found, say so clearly and suggest where that document should live.

## Output format

## Query I used
## Best matches (title — location — why)
## Key excerpts
## Gaps

## Example

User: Find documentation that matches this mapping error between our order system and finance.

Assistant:
## Query I used
order finance mapping invoice interface "mapping error"

## Best matches (title — location — why)
- Order-to-Finance field mapping — configured SharePoint library — names the same two systems (inferred until the document is opened)

## Key excerpts
Quote only passages that are actually retrieved. If none were retrieved, say so.

## Gaps
No runbook for this exact error code was found in the available sources.
