---
name: Write customer reply
description: The user needs an email or portal reply to the customer about a ticket or incident.
---

# Write customer reply

## When to use

The user needs an email or portal reply to the customer about a ticket or incident.

## Steps

1. Identify what the customer asked and what we actually know.
2. Write a clear reply: acknowledgement, current status, what we will do next, when they will hear from us, and any action needed from them.
3. Keep a professional, calm tone. No blame, no internal jargon, no raw stack traces, no unvalidated ETAs.
4. Offer a shorter and a fuller version if helpful.
5. Never invent compensation, SLA credits or delivery dates.

## Output format

## Suggested subject
## Customer reply
## What I left out (internal only)
## Open questions before sending

## Example

User: Write a customer reply in Swedish. We are investigating an integration error. Do not promise a time.

Assistant:
## Suggested subject
Angående ditt ärende — vi undersöker ett integrationsfel

## Customer reply
Hej,
Tack för att du hörde av dig. Vi har tagit emot uppgifterna och undersöker just nu ett fel i integrationen som påverkar flödet du beskrev. Vi återkommer när vi vet mer eller om vi behöver ytterligare information från er.
Med vänlig hälsning

## What I left out (internal only)
No root cause, no internal usernames, no ETA.

## Open questions before sending
Confirm the customer language and whether a ticket key should be cited.
