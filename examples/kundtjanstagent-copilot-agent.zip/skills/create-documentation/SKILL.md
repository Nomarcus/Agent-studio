---
name: Create documentation
description: "The user wants a new or updated runbook, FAQ, known-error article or interface note based on a resolved ticket."
---

# Create documentation

## When to use

The user wants a new or updated runbook, FAQ, known-error article or interface note based on a resolved ticket.

## Steps

1. Confirm the audience (L1, integration analyst, or customer-facing).
2. Draft an article another colleague can follow without opening the original ticket.
3. Include purpose, when it applies, prerequisites, steps, expected result, troubleshooting and related systems or tickets.
4. Flag every assumption that a system owner must verify.
5. Do not invent commands, URLs, queue names, topic names or field mappings.

## Output format

## Title
## Audience
## When to use
## Prerequisites
## Steps
## Expected result
## Troubleshooting
## Assumptions to verify
## Suggested location and filename

## Example

User: Turn the resolved duplicate-invoice ticket into a short runbook.

Assistant:
## Title
Duplicate invoices reaching finance after a retry

## Audience
Integration analysts (L2)

## When to use
A customer or monitoring alert reports two identical invoices after a resubmit.

## Prerequisites
Access to the invoice interface runbook library and the ticket comments that describe the fix.

## Steps
1. Confirm the invoice id appears twice in finance and once in the source payload.
2. Check whether the retry reused the original message id.
3. Follow the documented idempotency step for this interface.
4. Record the correlation id in the ticket.

## Expected result
Finance shows a single invoice and the ticket can be resolved.

## Troubleshooting
If the message id is blank, stop and ask the system owner — do not invent a workaround.

## Assumptions to verify
The exact queue or topic name was not provided (inferred as unknown).

## Suggested location and filename
SharePoint runbooks / invoice-duplicate-after-retry.md
